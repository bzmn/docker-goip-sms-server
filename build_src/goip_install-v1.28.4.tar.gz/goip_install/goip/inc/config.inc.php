<?php 
$dbhost='localhost';	//database server 
$dbuser='goip';		//database username 
$dbpw='goip';		//database password 
$dbname='goip';		//database name
$goipcronport='44444';  //goipcron port
$charset='utf8';
$endless_send=0;
$re_ask_timer=3;
?>
