<?php
require_once("session.php");
//if($_SESSION['goip_permissions'] > 1 )
	//WriteErrMsg("<br><li>Permission denied!</li>");
define("OK", true);
require_once("global.php");

require_once('filesms.htm');
?>
